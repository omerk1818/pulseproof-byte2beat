# PulseProof Coder template

This directory contains the tested local Docker template used for the Byte2Beat demonstration.

## One-click template upload

Upload `PulseProof_Coder_Template.zip` from this directory in Coder:

1. `Templates` → `New Template`
2. `Upload an existing template`
3. Select `PulseProof_Coder_Template.zip`
4. Create a workspace named `pulseproof-demo`
5. Keep the default public repository URL

## Source files

- `main.tf`: Coder agent, persistent Docker volume, dependency installation, model smoke test, Streamlit startup, and app health check.
- `build/Dockerfile`: Python 3.12 workspace image.
- `Start-Coder-Windows.ps1`: starts a local Coder server so Docker workspaces can connect.
- `evidence/`: screenshots showing an active Coder workspace and the working PulseProof application.

## Windows local server

Place `coder.exe` at `C:\Coder\coder.exe`, open PowerShell, and run:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\coder\Start-Coder-Windows.ps1
```

Or start it directly:

```powershell
& "C:\Coder\coder.exe" server --access-url "http://localhost:3000" --http-address "0.0.0.0:3000"
```

Docker Desktop must be running.

## Verified behavior

The template:

- clones the public GitHub repository;
- creates a persistent Python virtual environment;
- installs exact runtime dependencies, including `scikit-learn` required by the XGBoost sklearn wrapper;
- verifies that XGBoost, LightGBM, and CatBoost load and produce a prediction;
- starts Streamlit on port 8501;
- exposes the application through Coder as `PulseProof`;
- waits for `/_stcore/health` before declaring success.

Raw competition data are not included.
